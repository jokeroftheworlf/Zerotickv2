Zero Tick Water - Fabric client mod for Minecraft 1.21.11

BUILD (either):
  A) Locally: Java 21 + Gradle 9.2.1, run `gradle build` -> build/libs/zerotickwater-1.0.0.jar
  B) No install: push this folder to a GitHub repo; the workflow in .github/workflows
     builds it. Download the jar from Actions -> "zerotickwater-jar".

INSTALL: jar into .minecraft/mods with Fabric Loader 0.18+ and Fabric API for 1.21.11.

USE: press K in-game for settings (rebindable inside the GUI).
Pressing the trigger key (default R) sends 2 use-item clicks about 2 ms apart,
inside one client tick, from a single input (so no switch rebound).
Config file: .minecraft/config/zerotickwater.json

Use only where macros / input automation are allowed.
