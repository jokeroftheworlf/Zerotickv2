package com.example.zerotickwater;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Settings GUI: 3 pages (Input, Clicks, Feedback). Key binding is captured by polling GLFW. */
public class ConfigScreen extends Screen {

    private enum Target { NONE, TRIGGER, GUI }

    private static final String[] PAGE_NAMES = {"Input", "Clicks", "Feedback"};
    private static int lastPage = 0;

    private final Screen parent;
    private int page = lastPage;
    private Target listening = Target.NONE;
    private int armTicks = 0;

    public ConfigScreen(Screen parent) {
        super(Text.literal("Zero Tick Water - Settings"));
        this.parent = parent;
    }

    private ZtwConfig cfg() {
        return ZeroTickWaterClient.CONFIG;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int w = 220;
        int x = cx - w / 2;
        int y = 62;
        int step = 24;

        for (int i = 0; i < PAGE_NAMES.length; i++) {
            final int idx = i;
            ButtonWidget tab = ButtonWidget.builder(Text.literal(PAGE_NAMES[i]), b -> {
                page = idx;
                lastPage = idx;
                listening = Target.NONE;
                clearAndInit();
            }).dimensions(cx - 156 + i * 106, 30, 100, 20).build();
            tab.active = (i != page);
            addDrawableChild(tab);
        }

        switch (page) {
            case 0 -> {
                addToggle(x, y, w, "Mod enabled", () -> cfg().enabled, v -> cfg().enabled = v, false,
                        "Master switch. When off, the trigger does nothing.");
                y += step;

                addKeyButton(x, y, w, Target.TRIGGER);
                y += step;
                addKeyButton(x, y, w, Target.GUI);
                y += step;

                addToggle(x, y, w, "Hold to repeat", () -> cfg().holdToRepeat, v -> cfg().holdToRepeat = v, false,
                        "Off: one double-click per press. On: keeps firing while held (respects cooldown).");
                y += step;

                addSlider(x, y, w, "Cooldown (ticks)", 0, 20, cfg().cooldownTicks, v -> cfg().cooldownTicks = v,
                        "Minimum ticks between double-clicks. 20 ticks = 1 second.");
            }
            case 1 -> {
                addSlider(x, y, w, "Clicks per press", 1, 10, cfg().clickCount, v -> cfg().clickCount = v,
                        "How many use-item clicks one press sends. 2 = double click.");
                y += step;

                addSlider(x, y, w, "Gap between clicks (ms)", 0, 10, cfg().gapMs, v -> cfg().gapMs = v,
                        "Delay between clicks in milliseconds. 0 = back to back (microseconds apart).");
                y += step;

                addToggle(x, y, w, "Use offhand", () -> cfg().useOffhand, v -> cfg().useOffhand = v, false,
                        "Click with the offhand instead of the main hand.");
                y += step;

                addToggle(x, y, w, "Only with water bucket", () -> cfg().onlyWithWaterBucket,
                        v -> cfg().onlyWithWaterBucket = v, false,
                        "Only fire if the chosen hand holds a water bucket.");
                y += step;

                addToggle(x, y, w, "Require block target", () -> cfg().requireBlockTarget,
                        v -> cfg().requireBlockTarget = v, false,
                        "Only fire when your crosshair is on a block.");
            }
            default -> {
                addToggle(x, y, w, "Swing hand", () -> cfg().swingHand, v -> cfg().swingHand = v, false,
                        "Play the arm swing animation for each click.");
                y += step;

                addToggle(x, y, w, "Action bar messages", () -> cfg().actionBarMessages,
                        v -> cfg().actionBarMessages = v, false,
                        "Show a short message above the hotbar after each double-click.");
                y += step;

                addToggle(x, y, w, "Debug timing in chat", () -> cfg().debugChat, v -> cfg().debugChat = v, false,
                        "Prints each click with microseconds since the first click. Use it to check your gap.");
            }
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Reset to defaults"), b -> {
            cfg().copyFrom(new ZtwConfig());
            cfg().save();
            clearAndInit();
        }).dimensions(cx - 105, height - 52, 100, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx + 5, height - 52, 100, 20).build());
    }

    // ---------- widgets ----------

    private void addKeyButton(int x, int y, int w, Target target) {
        ButtonWidget btn = ButtonWidget.builder(keyLabel(target), b -> {
            listening = target;
            armTicks = 2;
            clearAndInit();
        }).dimensions(x, y, w, 20)
                .tooltip(Tooltip.of(Text.literal(target == Target.TRIGGER
                        ? "Click, then press a key or mouse button 3+ (side buttons). Backspace unbinds, Esc cancels."
                        : "Click, then press a key. Backspace unbinds, Esc cancels. Opens this menu in-game.")))
                .build();
        addDrawableChild(btn);
    }

    private Text keyLabel(Target target) {
        String prefix = target == Target.TRIGGER ? "Trigger key: " : "Open menu key: ";
        if (listening == target) {
            return Text.literal(prefix + "> press a key <");
        }
        Text name = target == Target.TRIGGER
                ? ZtwConfig.keyName(cfg().triggerCode, cfg().triggerIsMouse)
                : ZtwConfig.keyName(cfg().guiKeyCode, false);
        return Text.literal(prefix + "[ ").append(name).append(" ]");
    }

    private void addToggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set,
                           boolean rebuild, String tip) {
        ButtonWidget[] holder = new ButtonWidget[1];
        holder[0] = ButtonWidget.builder(toggleText(label, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            cfg().save();
            if (rebuild) {
                clearAndInit();
            } else {
                holder[0].setMessage(toggleText(label, get.getAsBoolean()));
            }
        }).dimensions(x, y, w, 20).tooltip(Tooltip.of(Text.literal(tip))).build();
        addDrawableChild(holder[0]);
    }

    private static Text toggleText(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    private void addSlider(int x, int y, int w, String label, int min, int max, int value,
                           IntConsumer set, String tip) {
        Slider s = new Slider(x, y, w, 20, label, min, max, value, v -> {
            set.accept(v);
            cfg().save();
        });
        s.setTooltip(Tooltip.of(Text.literal(tip)));
        addDrawableChild(s);
    }

    // ---------- key capture (called every client tick by the mod) ----------

    public void pollCapture(long window) {
        if (listening == Target.NONE) return;
        if (armTicks > 0) {      // ignore the tick(s) right after clicking the bind button
            armTicks--;
            return;
        }

        // keyboard (Esc is handled by the screen itself and just closes it)
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (k == GLFW.GLFW_KEY_ESCAPE) continue;
            if (GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS) {
                if (k == GLFW.GLFW_KEY_BACKSPACE) {
                    assign(-1, false);
                } else {
                    assign(k, false);
                }
                return;
            }
        }

        // extra mouse buttons (middle and side buttons) - only for the trigger
        if (listening == Target.TRIGGER) {
            for (int b = 2; b <= 7; b++) {
                if (GLFW.glfwGetMouseButton(window, b) == GLFW.GLFW_PRESS) {
                    assign(b, true);
                    return;
                }
            }
        }
    }

    private void assign(int code, boolean mouse) {
        if (listening == Target.TRIGGER) {
            cfg().triggerCode = code;
            cfg().triggerIsMouse = mouse;
        } else if (listening == Target.GUI) {
            cfg().guiKeyCode = code;
        }
        cfg().save();
        listening = Target.NONE;
        clearAndInit();
    }

    // ---------- screen plumbing ----------

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Changes save automatically. Hover options for details."),
                width / 2, 48, 0xFFA0A0A0);
    }

    @Override
    public void close() {
        cfg().save();
        MinecraftClient.getInstance().setScreen(parent);
    }

    // ---------- integer slider ----------

    private static class Slider extends SliderWidget {
        private final String label;
        private final int min;
        private final int max;
        private final IntConsumer onChange;

        Slider(int x, int y, int w, int h, String label, int min, int max, int initial, IntConsumer onChange) {
            super(x, y, w, h, Text.empty(), (initial - min) / (double) (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.onChange = onChange;
            updateMessage();   // the super constructor ran it before our fields existed
        }

        private int current() {
            return min + (int) Math.round(value * (max - min));
        }

        @Override
        protected void updateMessage() {
            if (label == null) return;
            setMessage(Text.literal(label + ": " + current()));
        }

        @Override
        protected void applyValue() {
            onChange.accept(current());
        }
    }
}
