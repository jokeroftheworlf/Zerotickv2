package com.example.zerotickwater;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;

/**
 * Zero Tick Water (Fabric client, MC 1.21.11, Yarn).
 *
 * One press of the trigger sends N use-item clicks (default 2) a few ms apart
 * inside the same client tick. Because it comes from ONE physical input there
 * is no switch rebound limiting the gap between the clicks.
 *
 * Use only where macros / input automation are allowed.
 */
public class ZeroTickWaterClient implements ClientModInitializer {

    public static ZtwConfig CONFIG;

    private boolean prevTriggerDown = false;
    private boolean prevGuiDown = false;
    private int cooldown = 0;

    @Override
    public void onInitializeClient() {
        CONFIG = ZtwConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();

        // Key capture inside the settings screen (polled, so it doesn't depend on screen input APIs).
        if (mc.currentScreen instanceof ConfigScreen screen) {
            screen.pollCapture(window);
        }

        boolean guiDown = ZtwConfig.isDown(window, CONFIG.guiKeyCode, false);
        if (guiDown && !prevGuiDown && mc.currentScreen == null) {
            mc.setScreen(new ConfigScreen(null));
        }
        prevGuiDown = guiDown;

        boolean down = ZtwConfig.isDown(window, CONFIG.triggerCode, CONFIG.triggerIsMouse);
        if (cooldown > 0) cooldown--;

        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) {
            prevTriggerDown = down;   // never fire while a menu is open
            return;
        }

        boolean fire = CONFIG.holdToRepeat ? down : (down && !prevTriggerDown);
        prevTriggerDown = down;

        if (CONFIG.enabled && fire && cooldown <= 0) {
            doClicks(mc);
        }
    }

    private void doClicks(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        Hand hand = CONFIG.useOffhand ? Hand.OFF_HAND : Hand.MAIN_HAND;

        if (CONFIG.onlyWithWaterBucket && !player.getStackInHand(hand).isOf(Items.WATER_BUCKET)) {
            return;
        }
        if (CONFIG.requireBlockTarget
                && (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.BLOCK)) {
            return;
        }

        cooldown = CONFIG.cooldownTicks;
        long gapNanos = CONFIG.gapMs * 1_000_000L;
        long start = System.nanoTime();

        for (int i = 0; i < CONFIG.clickCount; i++) {
            if (i > 0 && gapNanos > 0) {
                long end = System.nanoTime() + gapNanos;
                while (System.nanoTime() < end) {
                    Thread.onSpinWait();     // busy-wait: Thread.sleep is too coarse for ms gaps
                }
            }

            mc.interactionManager.interactItem(player, hand);
            if (CONFIG.swingHand) {
                player.swingHand(hand);
            }

            if (CONFIG.debugChat) {
                long us = (System.nanoTime() - start) / 1000;
                player.sendMessage(Text.literal("[ZTW] click " + (i + 1) + " at +" + us + " us"), false);
            }
        }

        if (CONFIG.actionBarMessages) {
            player.sendMessage(Text.literal("Clicked x" + CONFIG.clickCount), true);
        }
    }
}
