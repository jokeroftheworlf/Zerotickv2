package com.example.zerotickwater;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** All settings. Saved to config/zerotickwater.json. Uses raw GLFW codes (no version-fragile input APIs). */
public class ZtwConfig {
    // ---- Input ----
    public boolean enabled = true;
    public int triggerCode = GLFW.GLFW_KEY_R;      // -1 = unbound
    public boolean triggerIsMouse = false;
    public int guiKeyCode = GLFW.GLFW_KEY_K;       // opens this settings screen
    public boolean holdToRepeat = false;
    public int cooldownTicks = 2;

    // ---- Clicks ----
    public int clickCount = 2;
    public int gapMs = 2;                          // delay between clicks, 0-10 ms
    public boolean useOffhand = false;
    public boolean onlyWithWaterBucket = false;
    public boolean requireBlockTarget = false;

    // ---- Feedback ----
    public boolean swingHand = true;
    public boolean actionBarMessages = false;
    public boolean debugChat = false;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("zerotickwater.json");
    }

    public static ZtwConfig load() {
        ZtwConfig cfg = new ZtwConfig();
        try {
            Path p = path();
            if (Files.exists(p)) {
                ZtwConfig read = GSON.fromJson(Files.readString(p), ZtwConfig.class);
                if (read != null) cfg = read;
            }
        } catch (Exception e) {
            System.err.println("[ZeroTickWater] Could not read config, using defaults: " + e);
        }
        cfg.clamp();
        return cfg;
    }

    public void save() {
        clamp();
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[ZeroTickWater] Could not save config: " + e);
        }
    }

    public void clamp() {
        cooldownTicks = Math.max(0, Math.min(20, cooldownTicks));
        clickCount = Math.max(1, Math.min(10, clickCount));
        gapMs = Math.max(0, Math.min(10, gapMs));
    }

    public void copyFrom(ZtwConfig o) {
        enabled = o.enabled; triggerCode = o.triggerCode; triggerIsMouse = o.triggerIsMouse;
        guiKeyCode = o.guiKeyCode; holdToRepeat = o.holdToRepeat; cooldownTicks = o.cooldownTicks;
        clickCount = o.clickCount; gapMs = o.gapMs; useOffhand = o.useOffhand;
        onlyWithWaterBucket = o.onlyWithWaterBucket; requireBlockTarget = o.requireBlockTarget;
        swingHand = o.swingHand; actionBarMessages = o.actionBarMessages; debugChat = o.debugChat;
    }

    // ---------- input helpers ----------

    public static boolean isDown(long window, int code, boolean mouse) {
        if (code < 0) return false;
        if (mouse) return GLFW.glfwGetMouseButton(window, code) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(window, code) == GLFW.GLFW_PRESS;
    }

    public static Text keyName(int code, boolean mouse) {
        if (code < 0) return Text.literal("Unbound");
        if (mouse) {
            return Text.literal(switch (code) {
                case 0 -> "Left Mouse";
                case 1 -> "Right Mouse";
                case 2 -> "Middle Mouse";
                default -> "Mouse " + (code + 1);
            });
        }
        String special = switch (code) {
            case GLFW.GLFW_KEY_SPACE -> "Space";
            case GLFW.GLFW_KEY_ENTER -> "Enter";
            case GLFW.GLFW_KEY_TAB -> "Tab";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "Left Shift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "Right Shift";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "Left Ctrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "Right Ctrl";
            case GLFW.GLFW_KEY_LEFT_ALT -> "Left Alt";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "Right Alt";
            case GLFW.GLFW_KEY_UP -> "Up";
            case GLFW.GLFW_KEY_DOWN -> "Down";
            case GLFW.GLFW_KEY_LEFT -> "Left";
            case GLFW.GLFW_KEY_RIGHT -> "Right";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "Caps Lock";
            default -> null;
        };
        if (special != null) return Text.literal(special);
        if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F25) {
            return Text.literal("F" + (code - GLFW.GLFW_KEY_F1 + 1));
        }
        String name = GLFW.glfwGetKeyName(code, 0);
        if (name != null) return Text.literal(name.toUpperCase());
        return Text.literal("Key " + code);
    }
}
